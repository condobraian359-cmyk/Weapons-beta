OPERATION: LAST FRONT — PROTOTIPO ANDROID
==========================================

Este ZIP contiene el PROYECTO FUENTE de Godot 4. No es todavía un APK instalable.

REQUISITOS
- Godot Engine 4.3 o superior.
- Para generar un APK: Android Build Template de Godot y Android SDK configurado.
- Renderizador: Compatibility / OpenGL, elegido para ampliar compatibilidad con móviles.

ABRIR
1. Instala Godot 4 en una PC.
2. Descomprime el ZIP.
3. En Godot, pulsa Importar y selecciona project.godot.
4. Ejecuta la escena principal.

CONTROLES
- PC: WASD para moverse, Shift para correr, clic izquierdo para disparar.
- Android: botones en pantalla; desliza la parte derecha para mirar.
- Recargar, saltar y pausa desde la interfaz.

CONTENIDO DEL PROTOTIPO
- Un único escenario urbano construido con geometría 3D sencilla.
- Ocho bots básicos.
- Salud, munición, recarga y puntuación.
- Interfaz táctil inicial.

LIMITACIONES DE ESTA PRIMERA VERSIÓN
- Los bots usan una IA sencilla de persecución y línea de visión; todavía no hay navegación táctica avanzada.
- Los edificios son bloques de prototipo, no arte final.
- No incluye todavía modelos 3D profesionales, voces, música ni efectos cinematográficos.
- Debe probarse en el dispositivo y ajustarse antes de distribuirse.

NOTA
Para un teléfono de entrada, mantén sombras y resolución moderadas. Un juego 3D de calidad comercial requiere modelos, animaciones, audio y muchas rondas de pruebas.
